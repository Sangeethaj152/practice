package queue;
	import java.util.*;
	public class QueueAddRemove {
			public static void main(String args[])
			{
				Queue<String> list = new PriorityQueue<>();

				 list.add("Be");
				 list.add("Safe");
				 list.add("and healthy");
				System.out.println("before removing:"+ list);
				
				 list.remove("and healthy");

				System.out.println(" After removing :" + list);
				
				  
			}
}
