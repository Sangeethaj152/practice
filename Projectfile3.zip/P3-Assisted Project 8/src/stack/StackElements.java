package stack;

	import java.util.*;

	public class StackElements {
		
			public static void main(String args[])
			{
				Stack<String> line = new Stack<String>();

				line.add("I");
				line.add("want");
				line.add("to");
				line.add("go");
				line.add("to");
				line.add("Bangalore");
				System.out.println("Stack: " + line);
				String remove_elements = line.remove(5 );

				System.out.println("Removed element: "+ remove_elements);


				System.out.println("Final line: "	+ line);
			}
		
}
