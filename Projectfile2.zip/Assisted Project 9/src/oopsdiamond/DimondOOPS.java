
package oopsdiamond;
interface First 
{  
    default void show() 
    { 
        System.out.println("First"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("Second"); 
    } 
}  
public class DimondOOPS implements First, Second 
{  
    public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
    	DimondOOPS ob = new DimondOOPS(); 
        ob.show(); 
    } 
}

