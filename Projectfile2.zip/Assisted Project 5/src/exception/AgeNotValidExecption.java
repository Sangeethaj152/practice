package exception;

public class AgeNotValidExecption extends Exception {  
	

		
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private String msg;

		public AgeNotValidExecption(String msg) {
			 
			this.msg = msg;
			
		}

		@Override
		public String toString() {
			return "AgeNotValidExecption [message=" + msg + "]";
		}
	    
		
	
}
