package filehandling;


	import java.io.FileWriter;
	import java.io.File;
	import java.io.IOException;
	
	
	public class WriteFile {

		public static void createFileUsingFileClass() throws IOException
		{
			//create file
			File file= new File("c:\\files\\TestFileForPP.txt");
			
			if(file.createNewFile()) {
				System.out.println("File is Created");
			}
			else {
				System.out.println("File  is already Exist");
			}
			
			//write data to that file
			FileWriter  writer= new  FileWriter(file,false);//overWrites file
			writer.write("Welcome to my phase-1 3rd project...!");
			writer.close();
			
			
		}
	
		public static void main(String[] args) {
			try {
				 createFileUsingFileClass();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}}


