package filehandling;

	import java.io.File;
	
	import java.io.IOException;
	
	
	public class CreatingDeletionFile {
		
		
		public static void createFileUsingFileClass() throws IOException
		{
			//create file
			File file= new File("c:\\files\\DELETIONFILE.txt");
			
			if(file.createNewFile()) {
				System.out.println("File is Created");
			}
			else {
				System.out.println("File  is already Exist");
			}
			
			
		}
	
		public static void main(String[] args) {
			try {
				 createFileUsingFileClass();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}