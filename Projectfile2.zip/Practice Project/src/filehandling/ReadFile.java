package filehandling;

	import java.io.FileReader;
	import java.io.IOException;
	

	public class ReadFile {
		
		public static void readFileReaderClass() throws IOException
		{ 
			try (FileReader reader = new FileReader("c:\\files\\DELETIONFILE.txt")) {
				int data;
				
				while((data=reader.read())!=-1){
					
					System.out.print((char)data);
				}
			}
			
		}
		
		public static void main(String[] args) {
			
			
			try {
				readFileReaderClass();
				
			} catch (IOException e) {
				//e.printStackTrace();
				System.out.println("File not available");
			}
		}

	}
	