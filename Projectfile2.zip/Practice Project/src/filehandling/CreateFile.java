package filehandling;


	import java.io.File;
	
	import java.io.IOException;
	
	
	public class CreateFile {

		public static void createFileUsingFileClass() throws IOException
		{
			//create file
			File file= new File("c:\\files\\TestFileForPP.txt");
			
			if(file.createNewFile()) {
				System.out.println("File is Created");
			}
			else {
				System.out.println("File  is already Exist");
			}
			
			
		}
	
		public static void main(String[] args) {
			try {
				 createFileUsingFileClass();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}