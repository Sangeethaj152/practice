package arrays;

public class MultiDimensionalArray {

}
