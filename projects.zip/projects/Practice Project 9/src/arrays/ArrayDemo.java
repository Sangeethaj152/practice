package arrays;

public class ArrayDemo {

}
