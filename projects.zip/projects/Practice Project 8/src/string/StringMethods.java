package string;

public class StringMethods {

}
