package typecasting;

public class ExplicitTypecasting {
		
		public static void main(String [] args) {
			
			double s=23.33;
			
			int j=(int) s;  ///convert forcefully to int
			
			System.out.println("Converted Double "+s+" to int "+j);
			
		}

	}