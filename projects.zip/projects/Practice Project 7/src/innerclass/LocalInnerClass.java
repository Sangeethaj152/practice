package innerclass;

public class LocalInnerClass {

}
