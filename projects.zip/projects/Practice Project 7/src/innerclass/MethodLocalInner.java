package innerclass;

public class MethodLocalInner {

}
