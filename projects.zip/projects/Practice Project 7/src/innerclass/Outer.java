package innerclass;

public class Outer {

}
